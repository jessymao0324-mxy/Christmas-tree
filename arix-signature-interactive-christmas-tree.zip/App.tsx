import React, { useState, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Loader } from '@react-three/drei';
import Experience from './components/Experience';
import Overlay from './components/Overlay';
import { TreeState } from './types';
import { COLORS } from './constants';

const App: React.FC = () => {
  const [treeState, setTreeState] = useState<TreeState>(TreeState.SCATTERED);

  const toggleState = () => {
    setTreeState((prev) => 
      prev === TreeState.SCATTERED ? TreeState.TREE_SHAPE : TreeState.SCATTERED
    );
  };

  return (
    <div className="relative w-full h-screen bg-black">
      <Canvas
        shadows
        dpr={[1, 2]}
        camera={{ position: [0, 0, 20], fov: 45, near: 0.1, far: 100 }}
        gl={{ 
          antialias: false, // Post-processing handles AA usually, or we save perf
          toneMapping: THREE.ReinhardToneMapping,
          toneMappingExposure: 1.5
        }}
      >
        <Suspense fallback={null}>
          <Experience treeState={treeState} />
        </Suspense>
      </Canvas>
      
      <Loader 
        containerStyles={{ backgroundColor: COLORS.BG_DARK }}
        innerStyles={{ width: '200px', backgroundColor: '#333' }}
        barStyles={{ backgroundColor: COLORS.TIFFANY_BLUE }}
      />
      
      <Overlay currentState={treeState} onToggle={toggleState} />
    </div>
  );
};

// Needed for global THREE usage in gl prop
import * as THREE from 'three';

export default App;