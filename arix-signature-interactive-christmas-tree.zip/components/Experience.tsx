import React from 'react';
import { OrbitControls, Environment, PerspectiveCamera } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette, Noise } from '@react-three/postprocessing';
import { TreeState } from '../types';
import TreeParticles from './TreeParticles';
import FloatingSparkles from './FloatingSparkles';
import StarTopper from './StarTopper';
import { COLORS } from '../constants';

interface ExperienceProps {
  treeState: TreeState;
}

const Experience: React.FC<ExperienceProps> = ({ treeState }) => {
  return (
    <>
      <color attach="background" args={[COLORS.BG_DARK]} />
      
      {/* Dynamic Camera Controls */}
      <OrbitControls 
        enablePan={false}
        enableZoom={true}
        minDistance={10}
        maxDistance={40}
        autoRotate={treeState === TreeState.TREE_SHAPE}
        autoRotateSpeed={0.5}
        target={[0, 4, 0]} // Look at the center of the tree
      />

      {/* Lighting - Cinematic Setup */}
      <ambientLight intensity={0.2} color={COLORS.TIFFANY_BLUE} />
      <pointLight position={[10, 10, 10]} intensity={1.0} color={COLORS.WHITE} castShadow />
      <pointLight position={[-10, 5, -10]} intensity={0.5} color={COLORS.TIFFANY_BLUE} />
      <spotLight 
        position={[0, 20, 0]} 
        intensity={2} 
        angle={0.5} 
        penumbra={1} 
        color={COLORS.TIFFANY_BLUE} 
        castShadow
      />
      <Environment preset="city" />

      {/* The Main Subject */}
      <group position={[0, -2, 0]}>
        <TreeParticles treeState={treeState} />
        <StarTopper treeState={treeState} />
      </group>

      {/* Background Ambience */}
      <FloatingSparkles />

      {/* Post Processing for the "Luxury" Glow */}
      <EffectComposer disableNormalPass>
        <Bloom 
          luminanceThreshold={0.8} 
          mipmapBlur 
          intensity={1.5} 
          radius={0.6}
        />
        <Vignette eskil={false} offset={0.1} darkness={1.1} />
        <Noise opacity={0.02} />
      </EffectComposer>
    </>
  );
};

export default Experience;