import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { CONFIG, COLORS } from '../constants';

const FloatingSparkles: React.FC = () => {
  const pointsRef = useRef<THREE.Points>(null);
  
  const particles = React.useMemo(() => {
    const count = CONFIG.SPARKLE_COUNT;
    const positions = new Float32Array(count * 3);
    const scales = new Float32Array(count);
    
    for (let i = 0; i < count; i++) {
      const r = 30;
      positions[i * 3] = (Math.random() - 0.5) * r;
      positions[i * 3 + 1] = (Math.random() - 0.5) * r;
      positions[i * 3 + 2] = (Math.random() - 0.5) * r;
      scales[i] = Math.random();
    }
    
    return { positions, scales };
  }, []);

  useFrame((state) => {
    if (!pointsRef.current) return;
    const t = state.clock.getElapsedTime();
    // Slowly rotate the entire starfield
    pointsRef.current.rotation.y = t * 0.05;
    pointsRef.current.rotation.x = Math.sin(t * 0.05) * 0.1;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={CONFIG.SPARKLE_COUNT}
          array={particles.positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-scale"
          count={CONFIG.SPARKLE_COUNT}
          array={particles.scales}
          itemSize={1}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.15}
        color={COLORS.WHITE}
        transparent
        opacity={0.6}
        sizeAttenuation={true}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </points>
  );
};

export default FloatingSparkles;