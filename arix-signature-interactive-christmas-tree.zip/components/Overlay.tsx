import React from 'react';
import { TreeState } from '../types';

interface OverlayProps {
  currentState: TreeState;
  onToggle: () => void;
}

const Overlay: React.FC<OverlayProps> = ({ currentState, onToggle }) => {
  const isTree = currentState === TreeState.TREE_SHAPE;

  return (
    <div className="absolute top-0 left-0 w-full h-full pointer-events-none flex flex-col justify-between p-8 z-10">
      {/* Header - Aligned Top Left */}
      <header className="flex flex-col items-start mt-4 ml-2 opacity-90">
        <h1 className="text-6xl md:text-7xl text-white font-[Cinzel] tracking-widest uppercase drop-shadow-[0_0_15px_rgba(255,255,255,0.6)]">
          Jessy
        </h1>
        <div className="h-0.5 w-24 bg-[#0ABAB5] mt-2 mb-3 shadow-[0_0_8px_#0ABAB5]"></div>
        <p className="text-[#0ABAB5] font-[Cinzel] tracking-[0.2em] text-lg font-bold">
          Merry Christmas
        </p>
      </header>

      {/* Footer Controls */}
      <footer className="flex flex-col items-center mb-8 pointer-events-auto">
        <button
          onClick={onToggle}
          className={`
            group relative px-8 py-3 overflow-hidden rounded-full 
            border border-[#0ABAB5]/50 transition-all duration-500 ease-out
            hover:border-[#0ABAB5] hover:shadow-[0_0_20px_#0ABAB5]
            backdrop-blur-sm bg-black/30
          `}
        >
          {/* Button Background Animation */}
          <div className={`
            absolute inset-0 w-full h-full bg-[#0ABAB5] 
            transition-transform duration-500 ease-out origin-left
            ${isTree ? 'scale-x-100 opacity-20' : 'scale-x-0 opacity-0 group-hover:scale-x-100 group-hover:opacity-10'}
          `}></div>
          
          <span className="relative z-10 text-white font-[Cinzel] tracking-widest text-sm font-bold uppercase">
            {isTree ? 'Scatter Elements' : 'Assemble Tree'}
          </span>
        </button>
        
        <div className="mt-4 text-white/30 text-[10px] tracking-widest font-[Lato]">
          RENDERED IN REAL-TIME
        </div>
      </footer>
    </div>
  );
};

export default Overlay;