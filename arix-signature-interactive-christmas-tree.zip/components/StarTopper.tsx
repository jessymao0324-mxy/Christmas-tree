import React, { useRef, useMemo, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TreeState } from '../types';
import { CONFIG, COLORS } from '../constants';

// Configuration for the star particles
const STAR_PARTICLE_COUNT = 200;
const STAR_GEOMETRY = new THREE.OctahedronGeometry(0.12, 0); // Small diamond particles

interface StarTopperProps {
  treeState: TreeState;
}

const dummy = new THREE.Object3D();

const StarTopper: React.FC<StarTopperProps> = ({ treeState }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const groupRef = useRef<THREE.Group>(null);
  
  // Calculate particle positions
  const particles = useMemo(() => {
    const temp = [];
    
    // The star shape definition (Octahedron surface + volume)
    const R = 1.4; // Radius of the star topper

    for (let i = 0; i < STAR_PARTICLE_COUNT; i++) {
      // 1. Target Position (Tree Shape) - Local to the star center
      const treePos = new THREE.Vector3();
      let valid = false;
      
      // Rejection sampling for Octahedron shape: |x| + |y| + |z| <= R
      while (!valid) {
        treePos.set(
          (Math.random() - 0.5) * 2 * R,
          (Math.random() - 0.5) * 2 * R,
          (Math.random() - 0.5) * 2 * R
        );
        const sum = Math.abs(treePos.x) + Math.abs(treePos.y) + Math.abs(treePos.z);
        if (sum <= R) {
          valid = true;
          // Strong bias towards the surface for a defined shape
          if (Math.random() > 0.15) {
             treePos.multiplyScalar(R / sum);
          }
        }
      }

      // 2. Scatter Position - Relative to the star center
      // We want them to scatter high up and wide
      const scatterR = 20;
      const scatterPos = new THREE.Vector3(
        (Math.random() - 0.5) * scatterR,
        (Math.random() - 0.5) * scatterR + 8, // Float above the tree
        (Math.random() - 0.5) * scatterR
      );

      temp.push({
        treePos,
        scatterPos,
        // Individual animation attributes
        speed: Math.random() * 0.5 + 0.8,
        scale: Math.random() * 0.4 + 0.6,
        rotSpeed: Math.random() - 0.5
      });
    }
    return temp;
  }, []);

  // Initialize colors
  useLayoutEffect(() => {
    if (meshRef.current) {
      const c = new THREE.Color(COLORS.GOLD);
      for (let i = 0; i < STAR_PARTICLE_COUNT; i++) {
        meshRef.current.setColorAt(i, c);
      }
      meshRef.current.instanceColor!.needsUpdate = true;
    }
  }, []);

  const transitionRef = useRef(0);

  useFrame((state, delta) => {
    if (!meshRef.current || !groupRef.current) return;

    const time = state.clock.getElapsedTime();

    // 1. Animate the container Group
    // Place it at the top of the tree
    groupRef.current.position.set(0, CONFIG.TREE_HEIGHT + 0.5, 0);
    // Rotate the entire star assembly slowly
    groupRef.current.rotation.y = time * 0.4;
    // Gentle floating bob
    groupRef.current.position.y += Math.sin(time * 1.5) * 0.1;

    // 2. Handle State Transition
    const target = treeState === TreeState.TREE_SHAPE ? 1 : 0;
    transitionRef.current = THREE.MathUtils.lerp(transitionRef.current, target, delta * 2.5);
    const progress = transitionRef.current;

    // 3. Animate Particles
    for (let i = 0; i < STAR_PARTICLE_COUNT; i++) {
      const p = particles[i];

      // Interpolate position
      // Note: scatterPos is relative to the rotating group, creating a swirling galaxy effect when scattered
      dummy.position.lerpVectors(p.scatterPos, p.treePos, progress);

      // Individual particle rotation (sparkle effect)
      dummy.rotation.set(
        time * p.rotSpeed + i,
        time * p.rotSpeed + i, 
        time * p.rotSpeed
      );

      // Scale breathing
      const pulse = 1 + Math.sin(time * 3 + i * 0.5) * 0.1;
      dummy.scale.setScalar(p.scale * pulse);

      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
    }
    
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <group ref={groupRef}>
      <instancedMesh 
        ref={meshRef} 
        args={[STAR_GEOMETRY, undefined, STAR_PARTICLE_COUNT]}
        frustumCulled={false}
      >
        <meshStandardMaterial 
          color={COLORS.GOLD}
          emissive={COLORS.GOLD}
          emissiveIntensity={2.5}
          roughness={0.1}
          metalness={1.0}
          toneMapped={false}
        />
      </instancedMesh>
      
      {/* Glow Light */}
      <pointLight 
        distance={12} 
        intensity={2} 
        color={COLORS.GOLD} 
        decay={2.5} 
      />
    </group>
  );
};

export default StarTopper;