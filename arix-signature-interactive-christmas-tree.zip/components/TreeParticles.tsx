import React, { useMemo, useRef, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TreeState, ParticleData } from '../types';
import { CONFIG, COLORS, PARTICLE_GEOMETRY } from '../constants';

interface TreeParticlesProps {
  treeState: TreeState;
}

const dummy = new THREE.Object3D();
const tempVec = new THREE.Vector3();

const TreeParticles: React.FC<TreeParticlesProps> = ({ treeState }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  
  // Initialize Particles with Dual Positions
  const particles = useMemo(() => {
    const tempParticles: ParticleData[] = [];
    const { PARTICLE_COUNT, TREE_HEIGHT, TREE_RADIUS, SCATTER_RADIUS } = CONFIG;

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      // 1. Calculate Tree Position (Cone Spiral)
      // Normalized height (0 to 1)
      const yNorm = i / PARTICLE_COUNT; 
      const y = yNorm * TREE_HEIGHT;
      // Radius at this height (Cone shape)
      const r = TREE_RADIUS * (1 - yNorm) + 0.5; // +0.5 ensures top isn't infinitely sharp
      // Golden Angle for even distribution
      const theta = i * 2.39996; // Golden angle in radians
      
      const treePos = new THREE.Vector3(
        Math.cos(theta) * r,
        y,
        Math.sin(theta) * r
      );

      // Add some random jitter to tree pos so it's not perfect
      treePos.x += (Math.random() - 0.5) * 0.5;
      treePos.z += (Math.random() - 0.5) * 0.5;
      treePos.y += (Math.random() - 0.5) * 0.5;

      // 2. Calculate Scatter Position (Random Sphere)
      const u = Math.random();
      const v = Math.random();
      const thetaScatter = 2 * Math.PI * u;
      const phiScatter = Math.acos(2 * v - 1);
      const rScatter = SCATTER_RADIUS * Math.cbrt(Math.random()); // Cube root for uniform volume
      
      const scatterPos = new THREE.Vector3(
        rScatter * Math.sin(phiScatter) * Math.cos(thetaScatter),
        rScatter * Math.sin(phiScatter) * Math.sin(thetaScatter),
        rScatter * Math.cos(phiScatter)
      );

      // 3. Properties
      const rotation = new THREE.Euler(
        Math.random() * Math.PI,
        Math.random() * Math.PI,
        Math.random() * Math.PI
      );

      const scale = Math.random() * 0.5 + 0.5;
      
      // Color Palette Distribution (50% Blue, 50% White)
      let color;
      if (Math.random() > 0.5) {
        color = new THREE.Color(COLORS.TIFFANY_BLUE);
      } else {
        color = new THREE.Color(COLORS.WHITE);
      }

      tempParticles.push({
        treePosition: treePos,
        scatterPosition: scatterPos,
        rotation,
        scale,
        color,
        speed: Math.random() * 0.5 + 0.5,
      });
    }
    return tempParticles;
  }, []);

  // Set initial colors once
  useLayoutEffect(() => {
    if (meshRef.current) {
      particles.forEach((particle, i) => {
        meshRef.current!.setColorAt(i, particle.color);
      });
      meshRef.current.instanceColor!.needsUpdate = true;
    }
  }, [particles]);

  // Animation Loop
  // Re-implementing the frame loop with a cleaner animation strategy
  const transitionRef = useRef(0);

  useFrame((state, delta) => {
    if (!meshRef.current) return;

    const target = treeState === TreeState.TREE_SHAPE ? 1 : 0;
    
    // Smoothly move the global transition value
    transitionRef.current = THREE.MathUtils.lerp(transitionRef.current, target, delta * 1.5);
    const globalProgress = transitionRef.current;
    
    const time = state.clock.getElapsedTime();

    for (let i = 0; i < CONFIG.PARTICLE_COUNT; i++) {
      const particle = particles[i];
      
      // Calculate current position
      dummy.position.lerpVectors(particle.scatterPosition, particle.treePosition, globalProgress);
      
      // Add floating noise
      const hover = Math.sin(time * particle.speed + i * 0.1) * 0.2;
      dummy.position.y += hover;
      
      // Rotation: Spin them while moving
      dummy.rotation.copy(particle.rotation);
      dummy.rotation.x += time * 0.2 * particle.speed;
      dummy.rotation.y += time * 0.1 * particle.speed;

      // Scale: Pulse slightly
      const pulse = 1 + Math.sin(time * 2 + i) * 0.1;
      dummy.scale.setScalar(particle.scale * pulse);

      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
    }
    
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh
      ref={meshRef}
      args={[PARTICLE_GEOMETRY, undefined, CONFIG.PARTICLE_COUNT]}
      castShadow
      receiveShadow
    >
      <meshStandardMaterial
        color={COLORS.TIFFANY_BLUE}
        roughness={0.2}
        metalness={0.8}
        emissive={COLORS.TIFFANY_DARK}
        emissiveIntensity={0.2}
      />
    </instancedMesh>
  );
};

export default TreeParticles;