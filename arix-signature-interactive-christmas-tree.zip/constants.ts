import * as THREE from 'three';

// Palette
export const COLORS = {
  TIFFANY_BLUE: '#0ABAB5', // Classic Tiffany Blue
  TIFFANY_DARK: '#007A74',
  WHITE: '#FFFFFF',
  SILVER: '#F5F5F7',
  BG_DARK: '#020202',
  GOLD: '#FFD700', // Luxury Gold for the Star
};

// Configuration
export const CONFIG = {
  PARTICLE_COUNT: 2500,
  TREE_HEIGHT: 14,
  TREE_RADIUS: 6,
  SCATTER_RADIUS: 25,
  ANIMATION_SPEED: 2.5, // Lerp speed
  SPARKLE_COUNT: 400,
};

// Materials
export const PARTICLE_GEOMETRY = new THREE.DodecahedronGeometry(0.15, 0); 
// Low poly but catches light well