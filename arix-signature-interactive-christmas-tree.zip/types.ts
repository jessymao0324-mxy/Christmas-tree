import * as THREE from 'three';

export enum TreeState {
  SCATTERED = 'SCATTERED',
  TREE_SHAPE = 'TREE_SHAPE',
}

export interface ParticleData {
  // The target position when forming the tree
  treePosition: THREE.Vector3;
  // The random position when scattered
  scatterPosition: THREE.Vector3;
  // Random rotation for variety
  rotation: THREE.Euler;
  // Scale for variety
  scale: number;
  // Color variation
  color: THREE.Color;
  // Speed factor for individual particle animation
  speed: number;
}
